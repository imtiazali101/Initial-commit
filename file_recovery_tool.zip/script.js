// Handle file upload and form submission
const uploadForm = document.getElementById('upload-form');
const fileInput = document.getElementById('file-input');
const outputDirInput = document.getElementById('output-dir');
const progressBar = document.getElementById('progress-bar');
const log = document.getElementById('log');

uploadForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  
  const files = fileInput.files;
  const outputDir = outputDirInput.value;

  if (!files.length) {
    alert("Please select at least one file.");
    return;
  }

  if (!outputDir.trim()) {
    alert("Please enter a valid output directory.");
    return;
  }

  // Reset progress and log
  progressBar.style.width = '0%';
  log.innerHTML = '';

  const formData = new FormData();
  for (let file of files) {
    formData.append('files', file);
  }
  formData.append('output_dir', outputDir);

  try {
    const response = await fetch('/recover', { method: 'POST', body: formData });

    if (response.ok) {
      const result = await response.json();
      handleRecoveryResult(result);
    } else {
      logMessage(`Error: ${response.statusText}`);
    }
  } catch (error) {
    logMessage(`Error: ${error.message}`);
  }
});

// Handle recovery result
function handleRecoveryResult(result) {
  if (result.success) {
    logMessage("File recovery completed successfully!");
    progressBar.style.width = '100%';
  } else {
    logMessage("Some files could not be recovered.");
  }

  result.logs.forEach((entry) => logMessage(entry));
}

// Log message to UI
function logMessage(message) {
  const li = document.createElement('li');
  li.textContent = message;
  log.appendChild(li);
}
